package apr24assessment;

import java.util.Arrays;
import java.util.List;

abstract class Employee {
	abstract void setSalary(int salary);

	abstract int getSalary();

	abstract void setGrade(String grade);

	abstract String getGrade();

	void label() {
		System.out.print("Employee's data:\n");
	}
}

class Engineer extends Employee {
	private int salary;
	private String grade;

	void setSalary(int salary) {
		this.salary = salary;
	}

	int getSalary() {
		return salary;
	}

	void setGrade(String grade) {
		this.grade = grade;
	}

	String getGrade() {
		return grade;
	}

}

class Manager extends Employee {
	private int salary;
	private String grade;

	void setSalary(int salary) {
		this.salary = salary;
	}

	int getSalary() {
		return salary;
	}

	void setGrade(String grade) {
		this.grade = grade;
	}

	String getGrade() {
		return grade;
	}

}

public class EmployeeProfile {
	public static void main(String[] args) {
		List<String> employees = Arrays.asList("ENGINEER B 50000", "MANAGER A 70000", "MANAGER A 90000");
		String[] employeeDetailsArray;
		for (String var : employees) {
			employeeDetailsArray = var.split(" ");
			if (employeeDetailsArray[0].equals("ENGINEER")) {
				Engineer engineer = new Engineer();
				engineer.setGrade(employeeDetailsArray[1]);
				engineer.setSalary(Integer.parseInt(employeeDetailsArray[2]));
				engineer.label();
				System.out.println("GRADE : " + engineer.getGrade());
				System.out.println("SALARY : " + engineer.getSalary());
			} else if (employeeDetailsArray[0].equals("MANAGER")) {
				Manager manager = new Manager();
				manager.setGrade(employeeDetailsArray[1]);
				manager.setSalary(Integer.parseInt(employeeDetailsArray[2]));
				manager.label();
				System.out.println("GRADE : " + manager.getGrade());
				System.out.println("SALARY : " + manager.getSalary());
			}
		}
	}
}
