package apr24assessment;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StringReduction {

	public static int getMinDeletions(String s) {

		String[] ar = s.split("");
		List st = Arrays.asList(ar).stream().distinct().collect(Collectors.toList());

		return s.length() - st.size();
	}

	public static void main(String[] args) {
		String s = "abcab";
		int count = getMinDeletions(s);
		System.out.println(count);

	}

}
