package apr24assessment;

import java.util.ArrayList;
import java.util.List;

public class ShopperDelight {
	public static void main(String[] args) {
		int[] priceOfJeans = { 2, 3 };
		int[] priceOfShoes = { 4 };
		int[] priceOfSkirts = { 2, 3 };
		int[] priceOfTops = { 1, 2 };
		int budget = 10;
		int possibleWaysToBuy = 0;

		for (int i = 0; i < priceOfJeans.length; i++) {

			List<Integer> al = new ArrayList<Integer>();
			for (int j = 0; j < priceOfShoes.length; j++) {
				for (int k = 0; k < priceOfSkirts.length; k++) {
					for (int l = 0; l < priceOfTops.length; l++) {
						if (budget >= (priceOfJeans[i] + priceOfShoes[j] + priceOfSkirts[k] + priceOfTops[l])) {
							al.add(priceOfJeans[i]);
							al.add(priceOfShoes[j]);
							al.add(priceOfSkirts[k]);
							al.add(priceOfTops[l]);
							System.out.println(al);
							possibleWaysToBuy++;
						}
					}
				}
			}
		}
		System.out.println("No OF Possible ways to Buy.. :" + possibleWaysToBuy);
	}
}