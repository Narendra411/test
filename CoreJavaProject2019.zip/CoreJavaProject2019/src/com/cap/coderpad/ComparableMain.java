package com.cap.coderpad;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ComparableMain {

	public static void main(String[] args) {
		
		  Department d1 = new Department(1,"Store", "Navallur");
		  Department d2 = new Department(2,"Store1", "Koyembedu");
		  Department d3 = new Department(3,"Store2", "AnnaNagar");
		  
		  List<Address> list = new ArrayList();
		  
		  Address a1 = new Address(1, "PCT", "Tiruporrur");
		  Address a2 = new Address(2, "ChennaiOne", "Chennai");
		  Address a3= new Address(3, "Sipkot", "Bombay");
		  list.add(a1);
		  list.add(a2);
		  list.add(a3);
		  
		  Employee e1 = new Employee(15, "Ramu", "Raja", 1254, list, d1);
		  Employee e2 = new Employee(12, "Arya", "Kumar", 5782, list, d2);
		  Employee e3 = new Employee(23, "Venu", "Vimal", 365, list, d3);
		
		  List<Employee> empList = new ArrayList();
		  empList.add(e1);
		  empList.add(e2);
		  empList.add(e3);
		  
		  
		  empList.stream().sorted((emp1,emp2) -> emp1.getEmployeeid()- (emp2.getEmployeeid()))
		  .forEach(System.out::println);
		  
		  empList.forEach(System.out::println);
		  
		/*  System.out.println("---Sort By Name--");
		  
		  empList.sort(Comparator.comparing(Employee::getFirstName));
	        System.out.println(empList);
		  
		  
	        System.out.println("---Sort By Salary--");
			  
			  empList.sort(Comparator.comparing(Employee::getSalary));
		        System.out.println(empList);
			  


		        System.out.println("---Sort By DepLocation--");

				  empList.stream().sorted((emp1,emp2) -> emp1.getDepartment().getLocation().compareTo((emp2.getDepartment().getLocation())))
				  .forEach(System.out::println);
				  
				  System.out.println("---Sort By City--");  
	
		  
		  
				  empList.stream().sorted((emp1,emp2) -> emp1.getAddress().get(0).getCity().compareTo((emp2.getAddress().get(0).getCity())))
				  .forEach(System.out::println);
				  */
				  

				 empList.stream().forEach( s->{
					  List<Address> l=s.getAddress().stream().sorted((aa,a)->aa.getCity().compareTo(a.getCity())).collect(Collectors.toList());
					  s.setAddress(l);
				  });
				  empList.forEach(System.out::println);
				 
				  
	}

}
