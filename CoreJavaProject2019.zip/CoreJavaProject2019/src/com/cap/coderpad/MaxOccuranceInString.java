package com.cap.coderpad;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class MaxOccuranceInString {

	public static void main(
			String[] args) {/*
							 * String str = "aabbbbcc"; List<String> s1 = Arrays.asList(str.split(""));
							 * 
							 * 
							 * List<Character> distinctCharList = str.chars().mapToObj(e -> (char)
							 * e).distinct().collect(Collectors.toList()); List<Character> charList =
							 * str.chars().mapToObj(e -> (char) e).collect(Collectors.toList());
							 * 
							 * Map<Integer, Character> map = new HashMap<Integer, Character>();
							 * distinctCharList.stream().forEach(s -> {
							 * map.put(Collections.frequency(charList, s), s);
							 * 
							 * //System.out.println(map); });
							 * 
							 * Set<Integer> key = map.keySet(); int max = key.stream().reduce(0,
							 * Integer::max);
							 * 
							 * System.out.println("occurance :" + max); System.out.println("Character :" +
							 * map.get(max)); System.out.println("Index :" + str.indexOf(map.get(max)));
							 * 
							 */
		String str = "aabbabcc";
		List<Character> distCharList = str.chars().mapToObj(e -> (char) e).distinct().collect(Collectors.toList());
		List<Character> charList = str.chars().mapToObj(e -> (char) e).collect(Collectors.toList());

		Map<Character, Integer> map = new LinkedHashMap<>();
		List<Integer> listIn = new ArrayList<>();

		distCharList.stream().forEach(s -> {
			map.put(s, Collections.frequency(charList, s));
			listIn.add(Collections.frequency(charList, s));
		}); // End of forEach

		Integer max = listIn.stream().reduce(Integer::max).get();

		map.forEach((k, v) -> {
			if (v == max) {
				System.out.println("Character : " + k);
				System.out.println("Occurances : " + max);
				System.out.println("Index of char : " + str.indexOf(k));
			}//End of if block
		});// End of forEachmap block
		
		for(Map.Entry<Character, Integer>  i : map.entrySet()) {
			if(i.getValue() == max) {
			System.out.println("Occurances : " + i.getKey());
			break;
			
		}
		}

	}// End of main method
}//End of class
