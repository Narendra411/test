package com.cap.coderpad;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ShortestArrayLength {

	public static void main(String[] args) {
		List<List<Integer>> list = new ArrayList();
		list.add(Arrays.asList(1,2,3,4));
		list.add(Arrays.asList(0,2,7));
		list.add(Arrays.asList(4,12));
		list.add(Arrays.asList(1,2,5,6));
		
		  
		 List<Integer> sizeList = list.stream().map(s -> s.size()).sorted().collect(Collectors.toList());
		 System.out.println(sizeList);

	}

}
