package com.cap.coderpad;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FirstNonRepatingChar {

	public static void main(String[] args) {
	
	       String[] arr = { "array", "apple", "rat" };
	        List<String> list = Arrays.asList(arr);
	        list.forEach(str -> {
	           List<Character> charList = str.chars().mapToObj(e -> (char) e).collect(Collectors.toList());
	            Map<Character, Integer> map = new LinkedHashMap<>();
	            List<Integer> listIn = new ArrayList<>();
	            charList.stream().distinct().forEach(s -> {
	                map.put(s, Collections.frequency(charList, s));
	                listIn.add(Collections.frequency(charList, s));
	            });
	            //System.out.println("Values : "+map);
	            //System.out.println("ListValues : "+listIn);
             int min = Collections.min(listIn);
	            int t = 0;
	            for(Map.Entry<Character, Integer> m3:map.entrySet()) {
	                if (m3.getValue() == min) {
	                	if(t == 1) {
	                    System.out.println("Character : " + m3.getKey());                    
	                    break;
	                    
	                	}
	                	t++;
	                }
	            }
	            
	        });
	    
	}

}
