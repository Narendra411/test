package com.cap.java8;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class FlatMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> set = new HashSet<>();
		set.add("tire-");
		List<String> list = new LinkedList<>();
		Deque<String> queue = new ArrayDeque<>();
		queue.push("wheel-");
		Stream.of(set, list, queue).flatMap(x -> x.stream()).forEach(System.out::print);

		IntStream ints = IntStream.empty();
		IntStream moreInts = IntStream.of(66, 77, 88);
		Stream.of(ints, moreInts).flatMapToInt(x -> x).forEach(System.out::print);

	}

}
