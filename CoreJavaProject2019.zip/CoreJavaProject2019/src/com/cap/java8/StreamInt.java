package com.cap.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*** 2nd Question
		 * Stream<Integer> obj = Stream.iterate(1, i > i + 1);
		 *  boolean b = obj.anyMatch(1 -> i > 5); 
		 *  System.out.println(b);
		 */

		// *** 3rd Question
		Stream<String> stream = Stream.of("base", "ball");
		stream.mapToInt(s -> s.length()).forEach(System.out::print);

		// *** 5th Question
		List<Double> list = new ArrayList<>();
		list.add(5.4);
		list.add(1.2);
		Optional<Double> opt = list.stream().sorted().findFirst();
		System.out.println(" " + opt.get() + " " + list.get(0));

		// *** 6th Question
		Stream<Character> chars = Stream.of('o', 'b', 's', 't', 'a', 'c', 'l', 'e');
		chars.map(c -> c).collect(Collectors.toList()).forEach(System.out::print);
		;
		// *** 15th Question

		Stream<String> s = Stream.of("over the river", "through the woods", "to grandmother's house we go");
		//s.filter(n -> n.startsWith("t")).sorted(Comparator::reverseOrder);// .findFirst().ifPresent(System.out::println);
		
		//*** 16th Question
		Stream<Integer> stream1 = Stream.of(1, 2, 3);
		System.out.println(" "+stream1.findAny());

	}

}
