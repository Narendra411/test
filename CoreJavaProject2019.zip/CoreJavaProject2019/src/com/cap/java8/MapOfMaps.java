package com.cap.java8;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapOfMaps {

	public static void main(String[] args) {
		Map<Integer, Integer> map = new HashMap<>();
		map.put(9, 3);
		Set<Integer> result = map.keySet();
		System.out.println(result.iterator().next());

	}

}
