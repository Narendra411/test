package com.cap.java8;

import java.util.stream.Stream;

public class OptionalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stream<Character> stream = Stream.of('c', 'b', 'a'); // z1
		stream.findAny().ifPresent(System.out::println); // z2

	}

}
