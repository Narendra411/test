package com.cap.capgemini.iq;

import java.util.HashSet;

class people {
	int id  ;
	String name;
	
	public people(int id, String name) {
		this.id = id;
		this.name = name;
	}
}
public class HashSetDemo {



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "CAPGEMINI";
		
		String s2 = new String("CAPGEMINI");
		String s3 = new String("CAPGEMINI");
		
		HashSet set = new HashSet();
		set.add(new people(1,"cap"));
		set.add(new people(1,"cap"));
		set.add(s1);
		set.add(s2);
		set.add(s3);
		
		System.out.println("Hashset Contains : "+set.contains(new people(1,"cap")));
		System.out.println("Size :: "+set.size());
		

	}

}
