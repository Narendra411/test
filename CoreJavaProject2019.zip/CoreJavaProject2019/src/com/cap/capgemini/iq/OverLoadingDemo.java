package com.cap.capgemini.iq;

public class OverLoadingDemo {

	public void dis(String a) {
		System.out.println("--String--");
	}
	
	
	public void dis(Object a) {
		System.out.println("--Integer--");
	}
	
	public  Object mone() {
		return null;
	}
	
	public  String mone() {
		return "hello";
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OverLoadingDemo demo = new OverLoadingDemo();
		demo.dis(null); // The method dis(String) is ambigious for Overloading

	}

}
