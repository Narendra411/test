package com.cap.capgemini.iq;

interface A {
	int x = 10;

	default public Object display() {
		System.out.println("--- Interface A---");
		return null;
	}
}

interface B {
	int x = 10;

	default public String display() {
		System.out.println("--- Interface B---");
		return "String";
	}
}

public class AmbiguityInterface implements A, B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AmbiguityInterface obj = new AmbiguityInterface();
		obj.display();
		System.out.println("Instance variable in A : " + A.x);
		System.out.println("Instance variable in B : " + B.x);

	}

	@Override
	public String display() {
		// TODO Auto-generated method stub
		return (String) A.super.display();
	}

	

}
