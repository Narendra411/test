package com.cap.capgemini.iq;

public class ArrayWOSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int ar[] = { 2, 1, 3, 7, 6 };

		for (int i = 0; i < ar.length; i++) {

			for (int j = i + 1; j < ar.length; j++) {

				int temp;

				if (ar[i] > ar[j]) {
					temp = ar[i];
					ar[i] = ar[j];
					ar[j] = temp;
				}

			}

		}

		for (int i = 0; i < ar.length; i++) {
			System.out.print(ar[i]);
		}
	}

}
