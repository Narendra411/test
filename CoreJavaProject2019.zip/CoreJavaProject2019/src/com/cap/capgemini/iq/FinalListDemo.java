package com.cap.capgemini.iq;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class FinalListDemo {

	public static void main(String[] args) {
		// TODO Auto-genrated method stub
		
		final List<String> list; //= new ArrayList<String>();
	/*
		list.add("one");
		list.add("two");
		list.add("three");
	*/	
		List<String> l1 = new ArrayList<>(); 
		
		l1.add("five");
		list = l1; // The final local vairable list cannot be assigned.
		System.out.println(l1.size()+"  "+list.size());
		
		Iterator<String> it = list.iterator();
		while(it.hasNext())
			System.out.println("Values : "+it.next());
	
			

	}

}
