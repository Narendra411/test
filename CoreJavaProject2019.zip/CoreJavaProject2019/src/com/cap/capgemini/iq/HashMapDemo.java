

package com.cap.capgemini.iq;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<String,String> map = new HashMap<String,String>();
		map.put("US", "United States");
		map.put("US", "U.S.A");
		map.put(null, "keys");
        System.out.println(map.size());
        
        try {
          Set<Entry<String,String>> set = map.entrySet();
          set.remove(1);
          System.exit(0);
        }finally {
        	System.out.println("Infinite");
        }
          
          
          
          
          
	}

}
