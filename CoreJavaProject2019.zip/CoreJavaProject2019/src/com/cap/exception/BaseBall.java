package com.cap.exception;

public class BaseBall {
	//static int score = 1;

	public static void main(String... teams) {
		try {
			int score = 0; // try block variables are not visible to outside 
			System.out.print(score++);
		} catch (Throwable t) {
			//System.out.print(score++);
		} finally {
			//System.out.print(score++);
			
		}
		//System.out.print(score++);
	}
}
