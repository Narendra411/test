package com.cap.exception;

public class BasketBall {

	public static void main(String[] dribble) {
		try {
			System.out.print(1);
			throw new RuntimeException();
		} catch (RuntimeException e1x) {
			System.out.print(2);
		} catch (Throwable ex) {
			System.out.print(3);
		} finally {
			System.out.print(4);
			return;	
		}
		//System.out.print(5);

	}
}