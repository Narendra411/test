package com.cap.exception;

import java.io.File;
import java.io.IOException;

public class CheckedExc {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File obj = new File("C:\\Hello2.txt");
		try {
			boolean b = obj.createNewFile();
			System.out.println(b);
		}/* catch (IOException e) {                    // Hirerachy need to follow from child to parent
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
         catch(IOException |RuntimeException e) {
        	 System.out.println("I'm catch block");
         }
	}

}
