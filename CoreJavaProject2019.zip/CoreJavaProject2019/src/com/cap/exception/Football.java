package com.cap.exception;

public class Football {

	public static void main(String args[]) {
		try {
			System.out.print("A----");
			throw new RuntimeException("Out of bounds!");
		} catch (ArrayIndexOutOfBoundsException aioobe) {
			System.out.print('B');
			//throw t;
		} finally {
			System.out.print('C');
		}
	}
}
