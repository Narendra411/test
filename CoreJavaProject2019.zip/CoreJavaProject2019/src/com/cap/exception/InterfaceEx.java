package com.cap.exception;

 interface IPrinter {
	abstract int printData() throws PrintException;
}
 
 class PrintException extends Exception {
 }

 class PaperPrintException extends PrintException {
 }

public class InterfaceEx {

}
