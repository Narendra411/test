package com.cap.exception;

import java.io.*;

public class Printer {
	public void print() {
		try {
			throw new FileNotFoundException();
		} catch (IOException exception) {
			System.out.print("Z");
		} catch (Throwable enfe) {  // If you put FileNotFoundException in catch already caught exception.
			System.out.print("X");
		} finally {
			System.out.print("Y");
		}
	}

	public static void main(String... ink) {
		new Printer().print();
	}
}