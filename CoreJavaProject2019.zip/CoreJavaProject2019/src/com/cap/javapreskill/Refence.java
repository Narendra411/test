package com.cap.javapreskill;

class Mammal {}
class Reindeer extends Mammal{}
class Dog extends Mammal{}
class Man extends Mammal{}


public class Refence {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Reindeer r = new Reindeer();
   Dog d = new Dog();
   Man ma = new Man();
   Mammal m =ma;
   m = d; m = r;
   //r =m;
   
	}

}
