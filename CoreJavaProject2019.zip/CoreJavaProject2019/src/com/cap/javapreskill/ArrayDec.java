package com.cap.javapreskill;

public class ArrayDec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int[][] doublearray =  {{89,5},{8,6},{5,7}};
    
    int[][] doublearray1 = new int[3][];
    //int[][] doublearray2 = new int[][4]; row must not be empty declaration.
    int[][] doublearray3 = {{89},{6},{7}};
    String[][] doublearray4 = new String[3][3];
    System.out.println("Values : "+doublearray4[2][2] );
    
    Object ob = new int[] {1,2,3};
    int[] ar = (int[])ob;
    for(int i : ar)
    System.out.println(i+" ");
    
	}

}
