package com.cap.javapreskill;

public class GetData {

	private static int a = 10;
	public static int getData() {
		return 0;
	} 
	public static void Main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(getData());

	}

}
