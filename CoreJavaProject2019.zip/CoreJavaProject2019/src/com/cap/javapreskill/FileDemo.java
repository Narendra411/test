package com.cap.javapreskill;

import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File obj = new File("Hello.txt");
		System.out.println(obj.createNewFile()); // Compilation will fails if not throw IOEXception.

		int a = 30;
		do {
			System.out.println("Decreasing : " + a--);
		} while (a > 0); // Compilation will fails if you simply specify a in while();

	}

	static public void main(String ar) {
	}

	static public void main(float[] ar) {
		
	}

}
