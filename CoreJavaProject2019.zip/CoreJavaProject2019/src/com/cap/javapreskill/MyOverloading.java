package com.cap.javapreskill;

public class MyOverloading {

	int temp(int a) {
		System.out.println("one");
		return a;
	}

	String temp(Object a) {
		System.out.println("two");
		return "Obj";
	}

	String temp(String a) {
		System.out.println("three");
		return "String";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyOverloading o = new MyOverloading();
		MyOverloading o1 = new MyOverloading();
		String s = o.temp(o1);
		System.out.println("");
	}

}
