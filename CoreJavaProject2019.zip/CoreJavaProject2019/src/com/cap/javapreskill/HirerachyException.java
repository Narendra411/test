package com.cap.javapreskill;

import java.io.IOException;

interface Printable {
	boolean found(String path) throws IOException;
}

class Printer implements Printable {

	@Override
	public boolean found(String path) throws RuntimeException {
		// Code will compile there is no exception in program execute well.
		boolean f = false;
         
		return f;
	}

}

public class HirerachyException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			Printer p = new Printer();
			boolean res = p.found("C:\\path");
			System.out.println("Value : "+res);
		

	}

}
