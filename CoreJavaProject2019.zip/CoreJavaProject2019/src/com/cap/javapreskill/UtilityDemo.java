package com.cap.javapreskill;

import java.util.ArrayList;

interface A{
	void x();
}
class B implements A{
	public void x() {};
	public void y() {};
}

class C extends B{
	public void x() {};
}

public class UtilityDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     ArrayList<A> obj = new ArrayList<A>();
     obj.add(new B());
    // obj.add(new C());
     /*for(A i : obj) {
    	 i.x();
     }*/
     
 
	}

}
