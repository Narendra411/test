package com.capgemini.thread;

class Calculator extends Thread {
	int sum = 0;

	public void run() {

		synchronized (this) {

			for (int i = 0; i < 20; i++) {
				sum = sum + i;
			}
//			notify();

		}
	}
}

public class ThreadWaitExmp {

	public static void main(String[] args) {
		Calculator obj = new Calculator();
		obj.start();

		synchronized (obj) {
			try {
				obj.wait();
			} catch (InterruptedException e) {
			}
		}
		System.out.println("Value : " + obj.sum);
	}
}
