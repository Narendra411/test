package com.capgemini.thread;

class Q {

	int num;

	boolean valueSet = false;

	public synchronized void put(int num) {

		while (valueSet) {
			//System.out.println("Put while Wait : ");

			try { 
				//System.out.println("Put Wait : ");
				wait(); } catch (Exception e) {
			}
		}
		this.num = num;
		System.out.println("put : " + num);
		valueSet = true;
		notify();
	}

	public synchronized void get() {
/*		while (!valueSet) {
			System.out.println("Get while Wait : ");

			try { 
				System.out.println("Get Wait : ");
				wait();	} catch (Exception e) {}
		}*/
          System.out.println("Get valueSet : "+valueSet);
				System.out.println("Get : " + num);
		valueSet = false;
		notify();
	}
}

class Produces implements Runnable {

	Q q;

	public Produces(Q q) {
		this.q = q;
		Thread t1 = new Thread(this, "produces");
		t1.start();
	}

	@Override
	public void run() {

		int i = 0;
		while (true) {

			q.put(i++);
			try {
				Thread.sleep(500);
			} catch (Exception e) {
			}
		}

	}

}

class Consumes implements Runnable {

	Q q;

	public Consumes(Q q) {
		this.q = q;
		Thread t1 = new Thread(this, "consumes");
		t1.start();
	}

	@Override
	public void run() {

		while (true) {

			q.get();
			try {
				Thread.sleep(5000);
			} catch (Exception e) {
			}
		}

	}

}

public class InterThread {

	public static void main(String[] args) {

		Q obj = new Q();

		new Produces(obj);
		new Consumes(obj);

	}

}
