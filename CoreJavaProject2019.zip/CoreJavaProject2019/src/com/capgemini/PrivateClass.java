package com.capgemini;

public abstract class PrivateClass {

	abstract void show();
	
  public PrivateClass(String s) {
		System.out.println("==Default Pvt Const=="+s);
	}
	
	private PrivateClass() {
		System.out.println("==Pvt Const==");
	}
	
	public static void main(String[] args) {
		System.out.println("------Main--");
     
	}

}
