package com.capgemini;

class A {
}

class B extends A {
}

public class C extends B {

	public static void main(String[] args) {
		B obj = new B();

		if ((obj instanceof C))
			System.out.println("obj is instance of Class B");

		else if ((obj instanceof B) && (obj instanceof A) && (obj instanceof C))
			System.out.println("obj is instance of Class B & A");

		else
			System.out.println(((obj instanceof B) && ((obj instanceof C))));
		
		System.out.println("----");

	}

}
