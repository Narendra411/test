package com.capgemini;

abstract class MyAbstract {
	int a, b;
  
	public MyAbstract() {
		System.out.println("--No args Const--");
	}
	public MyAbstract(int a, int b) {
		this.a = a;
		this.b = b;
		System.out.println("Intialiaze the fields : " + a + " : " + b);
	}

}

public class MyAbs extends MyAbstract {

	public MyAbs() {
		//super();
		super(10, 20);
	}

	public static void main(String[] ar) {
		System.out.println("hello");
		MyAbs abs = new MyAbs();
	}

}