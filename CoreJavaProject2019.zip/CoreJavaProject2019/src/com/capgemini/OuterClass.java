package com.capgemini;

public class OuterClass extends PrivateClass {

	void show() {
		System.out.println("---Show--");
	}
	
	 OuterClass(String t) {
		super(t);
	}
	
	public static void main(String[] args) {
		PrivateClass ob = new OuterClass("one");
		ob.show();

	}

}
