package com.capgemini;

import java.util.*;

public class Employee implements Comparator<Employee>{
	String ename;
	int id;

	public Employee() {
		System.out.println("Default Cons");
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Employee(String name, int id) {
		this.ename = name;
		this.id = id;
	}

	@Override
	public String toString() {
		return "Employee [ename=" + ename + ", id=" + id + "]";
	}

	public static void main(String[] args) {

		List<Employee> emplist = new ArrayList<Employee>();
		emplist.add(new Employee("Ranga", 52));
		emplist.add(new Employee("Ranga", 25));
		emplist.add(new Employee("Sreenu", 30));
		emplist.add(new Employee("Kishore", 2));
		emplist.add(new Employee("Vennela", 8));

		emplist.stream().sorted((emp1, emp2) -> emp1.getEname().compareTo(emp2.getEname()))
				.forEach(System.out::println);

		/*
		 * emplist.sort(Comparator.comparing(Employee::getEname));
		 * System.out.println(emplist);
		 */

		/*
		 * Collections.sort(emplist, new Sortbyename());
		 */

		/*
		 * Comparator comp =
		 * Comparator.comparing(Employee::getEname).thenComparing(Employee::getId);
		 * emplist.sort(comp); System.out.print(emplist);
		 */

	}

@Override
	public int compare(Employee emp1, Employee emp2) {

		return emp1.id -emp2.id ;
	}

}
