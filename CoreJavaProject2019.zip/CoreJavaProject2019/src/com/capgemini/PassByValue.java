package com.capgemini;

public class PassByValue {

	public static void updateInt(int a) {
		a = 100;
		System.out.println("value of a" + a);
		
		//return a;
	}

	public static void main(String[] args) {
		int a = 10;
		System.out.println("Before update value\t" + a);

		updateInt(a);
		System.out.println("After update value\t" + a);

	}

}
