package com.capgemini;

import java.lang.reflect.Constructor;

public class SingletonTester {

	public static void main(String[] args)
			throws InstantiationException, IllegalAccessException, ClassNotFoundException {

		// Using Class Loader
		ClassLoader classLoader = SingletonTester.class.getClassLoader();
		
		Singleton s1 = Singleton.getInstance();
		
		Singleton s2 = null;

		//ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		try {
		Class<?> cls = classLoader.loadClass("com.capgemini.Singleton");

		@SuppressWarnings("unchecked")
		Constructor<Singleton> cons = (Constructor<Singleton>) cls.getDeclaredConstructor();
		  cons.setAccessible(true); s2 = cons.newInstance();
		  } 
	catch (Exception e) {
		  e.printStackTrace();
		  
		 }

	
		System.out.println(s1.hashCode() );

		/**
		 * Using Reflection API
		 * 
		 */
		//Singleton s1 = Singleton.getInstance();
		/*
		 * Singleton s2 = null; try { Class<Singleton> cls = Singleton.class;
		 * Constructor<Singleton> cons = cls.getDeclaredConstructor();
		 * cons.setAccessible(true); s2 = cons.newInstance(); } catch (Exception e) {
		 * e.printStackTrace();
		 * 
		 * }
		 */
		// System.out.println("Using Reflection API :" + s2.hashCode());
		/*ClassLoader cl = Singleton.class.getClassLoader();
		ClassLoader cl1 = ClassLoader.getSystemClassLoader();
		@SuppressWarnings("unchecked")
		// Class<Singleton> class1 = (Class<Singleton>) cl1.loadClass("D:\Eclipse Work
		// Spaces\\WorkSpace2019\\CoreJavaProject2019\\src\\com\\capgemini\\Singleton");
		Class<Singleton> forName = (Class<Singleton>) Class.forName("com.capgemini.Singleton.class");
		Singleton c2 = Singleton.class.newInstance();
		System.out.println("Using Instance :" + s1.hashCode());
		System.out.println("Using Classloader :" + forName.hashCode());
		System.out.println("Using Classloader :" + c2.hashCode());
*/
	}

}
