package com.capgemini;

class Test1{
	
}

 class Test2{
	
}

public class MyClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
