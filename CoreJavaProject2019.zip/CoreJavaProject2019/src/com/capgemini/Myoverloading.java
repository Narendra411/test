package com.capgemini;

public class Myoverloading {

	static int add(int a, int b) {
		System.out.println("int return type");
		return a + b;
	}
	static double add(double a, double b) {
		System.out.println("double return type");
		return a+b;
	}
	static void add(float a, float b) {
		System.out.println("void return type");
	}

	public static void main(String[] args) {
		Myoverloading.add(10, 10);
		Myoverloading.add(10.2d, 10.3d);
		Myoverloading.add(10f,20f);
		}
}
