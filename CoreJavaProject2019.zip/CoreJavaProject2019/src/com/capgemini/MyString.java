package com.capgemini;

public class MyString {

	public static void main(String[] args) {
/*		String s1 = new String("capgemini");
		String s2 = new String("capgemini");
		String s3 = "capgemini";
		System.out.println(s1.hashCode() + " love you " + s2.hashCode() + " hateyou " + s3.hashCode());
		System.out.println(s1 == s3);
		System.out.println(s1 == s2);
		StringBuilder s4 = new StringBuilder("capgemini");
		StringBuilder s5 = new StringBuilder("capgemini");
		Integer i1 = new Integer(12);
		Integer i2 = new Integer(12);
		System.out.println(i1.equals(i2));
		System.out.println(s4.equals(s5));
		System.out.println(s4 == s5);
*/
		String s6 = "Ranga";
		String s7 = new String("Ranga");
		String s8 = s6.intern();
		System.out.println(s7 == s8);
		System.out.println("--before apply on new object--");
		String a = "cap";
		String b = new String("cap");
		String c = b.intern();
		System.out.println( a == c);
		

	}

}
