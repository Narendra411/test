package com.capgemini;

class parent {

	private int id = 10;

	public parent() {
		System.out.println("==Parent Const===");
	}

	public int getId() {
		System.out.println("Getter : " + id);
		return id;
	}

	public void setId(int id) {
		this.id = id;
		System.out.println("Setter : " + this.id);
	}

	private void mone() throws ArrayIndexOutOfBoundsException {
		System.out.println("mone() in parent");
	}
}

public class Myoverriding extends parent {
	private int id = 20;

	// In overloading we cannot reduce the visibility of access specifier.
	protected void mone() throws IllegalArgumentException {
		System.out.println("mone() in child");

	}

	public Myoverriding() {
		System.out.println("==My overloading==");
	}

	public static void main(String[] args) {
		Myoverriding obj = new Myoverriding();
		parent obj1 = new Myoverriding();
		obj.mone();
		// obj.setId(15);
		System.out.println("child\t" + obj.getId());
		System.out.println("ID \t" + obj.id);

	}

}
