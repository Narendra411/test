package com.capgemini;

import java.util.Set;
import java.util.TreeSet;

public class TreesetDemo {

	public static void main(String[] args) {
		Set<Account> obj = new TreeSet<>();
		obj.add(new Account(1, "Capgemin", "pvt"));
		obj.add(new Account(2, "Tcs", "pvt"));
		obj.add(new Account(3, "Virtusa", "pvt"));
		obj.add(new Account(4, "Ford", "pvt"));
		System.out.println("---\t" + obj);

	}

}
