package com.capgemini;

public class Singleton {
	
	private static Singleton s1;
	
	private Singleton() {

		if(s1 != null) {
		   System.out.println("-- private cons--");
		throw new RuntimeException("Use getInstance()");
		  
	}
	}	
	
	
	/*@SuppressWarnings("unused")
	private static Class getClass(String classname) throws ClassNotFoundException {
	    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
	    if(classLoader == null) 
	        classLoader = Singleton.class.getClassLoader();
	      return (classLoader.loadClass(classname));
	}
*/
	
	public   static Singleton getInstance() {
		
		if(s1 == null)  // Check for first time
			synchronized(Singleton.class) {
				if(s1 == null) // check for second time
		
			s1 = new Singleton();
			}
		return s1;
		
	}

	public static void main(String[] args) {
		
		Singleton ob1 = Singleton.getInstance();
		Singleton ob2 = Singleton.getInstance();
		
		System.out.println("one :"+ob1.hashCode()+"\ntwo :"+ob2.hashCode());
		

	}

}
