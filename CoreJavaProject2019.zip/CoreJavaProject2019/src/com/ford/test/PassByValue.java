package com.ford.test;

class Test{
	int x;
	Test(int i){
		x = i;
	}
	Test(){
		x = 0;
	}
}
public class PassByValue {

	public static void main(String[] args) {
		Test t  = new Test(5);
		
	int k =	change(t);
		System.out.println(t.x+" "+k);

	}

	private static int change(Test t) {
		t = new Test();
		return t.x=10;
		
	}

}
