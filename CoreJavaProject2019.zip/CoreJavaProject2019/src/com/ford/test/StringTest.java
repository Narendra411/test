package com.ford.test;

public class StringTest {

	public static void main(String[] args) {
		String s1 ="Hello";
		String s2 = "Capgemini";
		s2.concat("How are you?");
		s1.concat(s2);
		System.out.println(s1);

	}

}
