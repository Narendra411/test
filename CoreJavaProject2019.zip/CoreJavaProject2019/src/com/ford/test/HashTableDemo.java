package com.ford.test;

import java.util.Hashtable;

public class HashTableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Hashtable ht = new Hashtable();
		ht.put("US", "UNITED STATES");
		ht.put("US", "U.S.A");
		ht.put(null, "one");
		System.out.println(ht.size());

	}

}
