package com.ford.test;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class FindDupinString {

	public static void main(String[] args) {
		String str = "krishna kanaparthi";

		char[] ch = str.toCharArray();
		Map<Character, Integer> chmp = new HashMap<Character, Integer>();
		for (char c : ch) {
			if (chmp.containsKey(c)) {
				chmp.put(c, chmp.get(c) + 1);
			} else {
				chmp.put(c, 1);
			}
		}

		Set<Character> keys = chmp.keySet();
		for (Character c : keys)
			if (chmp.get(c) > 1) {
				System.out.println(c + " is " + chmp.get(c) + " times");
			} // end of if;

		System.out.println("values in char\t" + chmp);
	}

}
