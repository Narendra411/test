package com.ford.test;

class A{
	
	void showMyRecordInLastYearDatabase() {
		System.out.println("---Class A--");
	}
}

class B extends A{
	
	void showMyRecordInLastYearDataBase() {
		System.out.println("---Class B--");
	}
}

public class AnnotationDemo {

	public static void main(String[] args) {
		B obj = new B();
		
		obj.showMyRecordInLastYearDatabase();

	}

}
