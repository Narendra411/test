package com.ford.test;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class DupCharFin {

	public static void main(String[] args) {
		String str = "hello how are you";
		int[] a = new int[] { 1, 2, 3, 1, 2, 4, 5, 6 };
		char[] ch = str.toCharArray();
		Map<Character, Integer> chmp = new HashMap<Character, Integer>();
		for (char c : ch) {
			if (chmp.containsKey(c)) {
				chmp.put(c, chmp.get(c) + 1);
			} else {
				chmp.put(c, 1);
			}
		}

		Set<Character> keys = chmp.keySet();
		for (Character c : keys)
			if (chmp.get(c) > 1) {
				System.out.println(c + " is " + chmp.get(c) + " times");
			}// end of if;
		Map<Integer,Integer> intmp =  new HashMap<Integer,Integer>();
		for(int i : a) {
			if(intmp.containsKey(i)) {
				intmp.put(i, intmp.get(i) + 1);
			}else {
				intmp.put(i, 1);
			}
		}
		
		Set<Integer> intkeys = intmp.keySet();
		for(int i : intkeys)
			if(intmp.get(i) > 1) {
				System.out.println(i+" is "+intmp.get(i)+" times ");
			}
		System.out.println("values in char\t"+chmp);
		System.out.println("values in char\t"+intmp);

	}


	
}
