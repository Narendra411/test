package com.ford.test;

public class MyString {

	public static void main(String[] args) {
		String s1 =  new String("lion");
		String s2 = "lion";
		String s3 = new String("lion");
		     s3.concat("virtusa");
		     s3.concat("consultant");
		     System.out.println(s3);
		     StringBuffer sb = new StringBuffer();
		     sb.append("virtusa");
		    String s = sb.append("cons")+"pvt";
		     System.out.println(sb+" "+s);
		//s2 = s1;
		System.out.println(2 == 2);
		System.out.println(s1.hashCode() == s3.hashCode());

	}

}
