package com.ford.test;

import java.util.Scanner;

public class Fibonanci {

	public static void main(String[] args) {
		int a=0,b=1,temp=0, n=10;
//		while(n > 0) {
//			temp = a+b;
//			a = b;
//			b = temp;
//			n--;
//			System.out.print(" "+temp);
//		}//while
		int temp1 = 0;
		Scanner sc = new Scanner(System.in);
		int sn = sc.nextInt();
		while( temp1 < sn) {
			temp1 = a + b;
			a = b;
			b = temp1;
		}
		if( temp1 == sn) 
			System.out.println("Palindrome");
			else
				System.out.println("not palindrome");
		
		

	}

}
