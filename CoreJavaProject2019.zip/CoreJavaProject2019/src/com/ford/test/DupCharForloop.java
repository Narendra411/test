package com.ford.test;

public class DupCharForloop {

	public static void main(String[] args) {
		String str = "test1 test2";
		String sa ="hello";
		System.out.println("length\t"+sa.length());
		int count = 0;
		char[] s1 = str.toCharArray();
		for (int i = 0; i < str.length(); i++) {
			for (int j = i + 1; j < str.length(); j++) {
				if (s1[i] == s1[j]) {
					count++;
					System.out.println("duplicates values in string \t" + s1[i]);
					break;
				}

			}
		}
		int count1 = 0;
		int[] ar = new int[] {1,2,3,1,2,3,4,5,6,7,8};
		
		for(int k=0;k < ar.length; k++) {
			for(int l = k+1; l < ar.length; l++) {
				if(ar[k] == ar[l]) {
					count1++;
					System.out.println(count1+"duplicates values in int\t"+ar[k]);
					break;
				}
			}
		}

	}

}
