package com.ford.test;

import java.util.HashSet;
import java.util.Set;

public class DuplicateValuesString {

	public static void main(String[] args) {
		String str = "";
		String words[] = str.split(" ");
		Set<String> inp = new HashSet<String>();
		
		Set out = new HashSet();
        for(String i : words) {
        	if(!inp.add(i)) {
        		//System.out.println("\t-->\t"+inp.add(i));
        		out.add(i);
        	}
        }
	System.out.println("Without Dup\t"+inp+"\tDuplicate\t"+out);	
}
}
