package com.ford.test;

@FunctionalInterface
interface CitiDev {
	 //void mone();
	 void mtwo(int a);
	 default void mthree() {
		 System.out.println("Three");
	 }
	 static void mfour() {
		 System.out.println("Four");
	 }
}


public class FunctImp  {

	public void mone() {
		System.out.println("Functional Interface");
	}
	
	public static void main(String[] args) {
		
		FunctImp obj = new FunctImp();
		obj.mone();
    
	// using Functional Interface
		
		CitiDev ob = (b) ->{
			System.out.println("Implementing Lambda Expression  11"+b);
		};
		
		
     ob.mtwo(1);
     ob.mthree();
     CitiDev.mfour();
	}

}
