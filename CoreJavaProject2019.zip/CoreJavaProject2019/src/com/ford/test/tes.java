package com.ford.test;

class tes1 {
protected int sc =10;
	private int sum(int a, int b) {
	System.out.println("super class");
	return 1;
}
public void diff(int a, int b) {
	
}
}

public class tes extends tes1 {

	public int sum(int a, int b) {
		System.out.println("child class"+sc);
	return 12;
	}
	public void diff(int a, int b) {}
	public static void main(int[] ar) {
		System.out.println("int main");
	}
 public static void main(String[] args) {
	tes ob = new tes();
	int a = ob.sum(1, 2);
	
}
}


