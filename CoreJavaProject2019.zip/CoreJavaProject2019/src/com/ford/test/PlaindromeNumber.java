package com.ford.test;

import java.util.Scanner;

public class PlaindromeNumber {

	public static void main(String[] args) {
		String ori,rev ="";
		 Scanner sc = new Scanner(System.in);
		 ori = sc.nextLine();
		 //int d = sc.nextInt();
		 //System.out.println("value of \t"+d);
		 for(int k = ori.length()-1; k >= 0 ;k--)
			 rev = rev + ori.charAt(k);
		 if(ori.equals(rev))
			 System.out.println("Palindrome");
		 else
			 System.out.println("Not Palindrome");
			 
	}

}
