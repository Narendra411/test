package com.ford.test;

public abstract class MyAbstract {
 public abstract void mone();
}
