package com.ford.test;

import java.util.ArrayList;
import java.util.List;

public class AnnotationSuppress {
	//@Deprecated
	void mone() {
		System.out.println("It's depericated method");
	}

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		
		AnnotationSuppress as = new AnnotationSuppress();
		ArrayList ob =  new ArrayList();
		ob.add(1);
		ob.add(2);
		ob.add("hello");
		
		
		as.mone();
		for(Object obj: ob) {
			System.out.println("values in list\t"+obj);
		}

	}

}
