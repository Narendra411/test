package com.ford.test;

class InvalidAgeException extends Exception {
	public InvalidAgeException(String s) {
		super(s);
	}
}

public class CustomException {

	static void validate(int age) throws Exception {
		if (age < 18) {
			throw new InvalidAgeException("Not valid Age");
		}
	}

	public static void main(String[] args) {
		try {
			validate(15);
		} catch (Exception e) {
			System.out.println("caught\t" + e.getMessage());
		}

	}

}
