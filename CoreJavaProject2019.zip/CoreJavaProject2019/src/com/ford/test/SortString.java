package com.ford.test;
import java.util.*;

public class SortString {
	    public static void main(String[] args) 
	    { 
	        Set<StringBuffer> str = new TreeSet<>(); 
	        str.add(new StringBuffer("Sohan")); 
	        str.add(new StringBuffer("Raja")); 
	        str.add(new StringBuffer("Harish")); 
	        str.add(new StringBuffer("Ram")); 
	        System.out.println(str); 
	    } 
	
}
