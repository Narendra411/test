package com.ford.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class LambdaExp {

	public static void main(String[] args) {
		Map<String, Integer> items = new HashMap<String, Integer>();
		items.put("a", 10);
		items.put("b", 20);
		items.put("c", 30);
		items.put("d", 40);

		items.forEach((k, v) -> System.out.println("Item " + k + " Value " + v));
		
		items.forEach( (k,v) -> {
			if("b".equals(k)) {
				System.out.println("Hello b value");
			}
							
		});
		
		List<String> lst = new ArrayList<String>();
		lst.add("10");
		lst.add("20");
		lst.add("30");
		lst.add("40");
		lst.forEach((k) -> System.out.println("Lam\t"+k));
		lst.forEach(System.out::println);	
		lst.stream()
		   .filter(s -> s.contains("20"))
		   .forEach(System.out::println);

	}

}
