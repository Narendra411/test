package com.ford.test;

public class TestClass {
	int a =10;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + a;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TestClass other = (TestClass) obj;
		if (a != other.a)
			return false;
		return true;
	}

	
	 String mone() {
		 System.out.println("-----");
		 return "hello";
	}
	public static void main(String[] args) {
		System.out.println("Hello Ranga..!");
		new TestClass().mone();
	}
}
