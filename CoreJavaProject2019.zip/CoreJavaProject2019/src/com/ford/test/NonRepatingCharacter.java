package com.ford.test;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class NonRepatingCharacter {

	public static void main(String[] args) {
		String str = "geeksforgeeks";

		char[] ch = str.toCharArray();
		Map<Character, Integer> chmp = new HashMap<Character, Integer>();
		for (char c : ch) {
			if (chmp.containsKey(c)) {
				chmp.put(c, chmp.get(c) + 1);
			} else {
				chmp.put(c, 1);
			}
		}

		for ( char c : chmp.size()) {
			if (chmp.get(c)) == 1) {
				System.out.println(chmp.get(j));
				break;
			}
		}

	}
}
