package com.ford.test;

public class Mytry {

	public static void main(String[] args) {
	try {
		System.out.println("Hello");
		int i =10/0;
		}catch(Exception e){
		e.printStackTrace();
		}
        finally {
        	System.out.println("Your are selected");
        }
	
	}

}
