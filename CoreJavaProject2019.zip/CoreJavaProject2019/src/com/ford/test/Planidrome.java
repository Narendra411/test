package com.ford.test;

public class Planidrome {

	public static void main(String[] args) {
		String s1 = "abccba";
		StringBuilder sb = new StringBuilder(s1);
		StringBuilder s2 = sb.reverse();
        if(s1.equals(s2.toString()))
        	System.out.println("Palindrome");
        else
        	System.out.println("not palindrome");
        String sr = "";
        for( int k = s1.length()-1; k >= 0 ;k--) {
        	sr = sr + s1.charAt(k);
        	if(s1.equals(sr))
        		System.out.println("PALINDROME");
        }
	}

}
