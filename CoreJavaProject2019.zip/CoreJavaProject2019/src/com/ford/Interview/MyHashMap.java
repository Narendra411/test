package com.ford.Interview;

import java.util.HashMap;

public class MyHashMap {

	public static void main(String[] args) {
		HashMap<String,Integer> map = new HashMap<String,Integer>();
		map.put("FB", 1);
		map.put("Ea", 2);
		
		System.out.println(map);

	}

}
