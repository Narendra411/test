package com.ford.Interview;
class parent{
	protected void print() {
		System.out.println("Super class print");
	}
	public void mone() {
		System.out.println("--parent mone--"+a);
	}
	int a=10;
}
public class Myoverriding extends parent{
  int a=20;
	public void print() {
		
		//super.print();
		System.out.println("Child class print");
		
	}
	public void mone() {
		System.out.println("--Child mone---"+a);
	}
	
	public static void mtwo(parent a) {
		if(a instanceof Myoverriding)
			System.out.println("downcasting perform");
		
	}
	
	public static void main(String[] args) {
		Myoverriding c1 = new Myoverriding();
		parent c2 = new Myoverriding();  //UpCasting
		
		c2.print();
		c2.mone();
		
		parent c3 = new Myoverriding();// DownCasting
		parent c4 = new parent();
		c4.mone();
		 mtwo(c3);
		 
		 mtwo(c4);

	}

}
