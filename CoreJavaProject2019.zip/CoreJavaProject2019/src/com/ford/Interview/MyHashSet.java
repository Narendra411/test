package com.ford.Interview;

import java.util.HashSet;

public class MyHashSet {

	public static void main(String[] args) {
		HashSet set = new HashSet();
		
		String s = new String("Hello");
		String s1 = new String("Hello");
		StringBuilder s2 = new StringBuilder("Hello");
		StringBuilder s3 = new StringBuilder("Hello");
		StringBuffer s4 = new StringBuffer("Hello");
		StringBuffer s5 = new StringBuffer("Hello");
		System.out.println(s.hashCode());
		System.out.println(s1.hashCode());
        System.out.println(s2.hashCode());
        System.out.println(s3.hashCode());
        System.out.println(s4.hashCode());
        System.out.println(s5.hashCode());
		set.add(s);
		set.add(s1);
		set.add(s2);
		set.add(s3);
		set.add(s4);
		set.add(s5);
			
       System.out.println("Values\t"+set);
	}

}
