package com.ford.Interview;

interface A {
	default void something() {
		System.out.println("Interface A");
	}

}

interface B {
	default void something() {
		System.out.println("Interface B");
	}
}

public class FuncInterfaceC implements A, B {

	public static void main(String[] args) {

		FuncInterfaceC ob = new FuncInterfaceC();
		ob.something();
		
		

	}

	@Override
	public void something() {
		// TODO Auto-generated method stub
		A.super.something();
	}

	
	

}
