package com.innerclass;

abstract class person {

	public person() {
		System.out.println("Private Constructor");
	}
	
	void eat() {
		System.out.println("Eating well!!");
	}

	abstract void sleep();
}

public class AnonymousInnerClass  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		person obj = new person() {

			@Override
			void sleep() {
				System.out.println("Sleeping properly!!");

			}

		};
		obj.eat();
		obj.sleep();

	}

}
