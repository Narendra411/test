package com.innerclass;

public class LocalInnerClass {

	String s = "Raja";

	void display() {

		int a = 10;
		
		System.out.println("-----");

		class local {

			void msg() {
				System.out.println("Method variable\t" + a);
				System.out.println("instance variable " + s);
			}
		}
		local obj = new local();
		obj.msg();
	}

	public static void main(String[] args) {
		// TO
		DO Auto-generated method stub
		
		
		LocalInnerClass inst = new LocalInnerClass();
		inst.display();

	}

}
