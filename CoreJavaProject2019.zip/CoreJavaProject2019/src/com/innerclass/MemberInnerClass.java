package com.innerclass;

public class MemberInnerClass {

	private int a = 10;

	class Inner {

		void msg() {
			System.out.println("Outer class variable\t" + a);

		}
	}

	public static void main(String[] args) {

		MemberInnerClass obj = new MemberInnerClass();
		MemberInnerClass.Inner obj1 = obj.new Inner();
		obj1.msg();

	}

}
