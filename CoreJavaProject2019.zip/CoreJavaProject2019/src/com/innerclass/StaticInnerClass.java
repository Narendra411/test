package com.innerclass;

public class StaticInnerClass {

	static String s = "Raja";
	String s1 = "Ranga";

	static class NesstedInner {
    static int  a = 100;
		void msg() {
			System.out.println("Iam from static nested inner " + s);
		

		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StaticInnerClass.NesstedInner obj = new StaticInnerClass.NesstedInner();
		NesstedInner ob1 = new StaticInnerClass.NesstedInner();
		
		//System.out.println("hello\t"+);
		obj.msg();
		ob1.msg();

	}

}
