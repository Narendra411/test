package apr20assessment;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

public class Numerology {

	public static void main(String[] args) {
		char[] c = { 'A', 'I', 'J', 'Q', 'Y' }; // - 1
		String s = Arrays.toString(c);

		char[] c1 = { 'B', 'K', 'R' };// -2
		String s1 = Arrays.toString(c1);
		char[] c2 = { 'C', 'G', 'L', 'S' }; // - 3
		String s2 = Arrays.toString(c2);
		char[] c3 = { 'D', 'M', 'T' }; // - 4
		String s3 = Arrays.toString(c3);
		char[] c4 = { 'E', 'H', 'N', 'X' };// -5
		String s4 = Arrays.toString(c4);
		char[] c5 = { 'U', 'V', 'W' };// -6
		String s5 = Arrays.toString(c5);
		char[] c6 = { 'O', 'Z' };// -7
		String s6 = Arrays.toString(c6);
		char[] c7 = { 'F', 'P' }; // -8
		String s7 = Arrays.toString(c7);

		String str = "RANGA";
		char[] charArray = str.toCharArray();
		int[] ar = new int[5];
		for (int i = 0; i < str.length(); i++) {
			if(charArray[i] == ('A' 'B')) {
				
			}
		} // for

		for (int i : ar)
			System.out.println(ar[i]);

	}

}
