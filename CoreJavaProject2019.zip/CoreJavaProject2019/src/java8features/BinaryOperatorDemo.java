package java8features;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.stream.Collectors;	

public class BinaryOperatorDemo {

	public static void main(String[] args) {
		
		int[] ar = {10,20,30,40};
		List<Integer> values1 = Arrays.stream(ar).boxed().collect(Collectors.toList());
		List<Integer> values = Arrays.asList(1,2,3,4,5,6);
		List<int[]> vs = Arrays.asList(ar);
		System.out.println("list\t"+vs.size()+"--"+values.size());
		int i = Arrays.stream(ar).reduce(0, (x,y) -> x +y);
		System.out.println("Sum of Array\t"+i);
				
		BinaryOperator<Integer> b = new BinaryOperator<Integer>()
		{
		
			
			@Override
			public Integer apply(Integer t, Integer u) {
				// TODO Auto-generated method stub
				return t+u;
			}
			 	
		};
		
		int j =values.stream().map((c) -> c*2)
				.reduce(0, b);
		System.out.println("Normalt\t"+j);
		
		
		

	}

}
