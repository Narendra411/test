package java8features;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.omg.CORBA.portable.BoxedValueHelper;

public class FlatMapDemo {

	public static void main(String[] args) {
		
		
		List<Integer> l1 = Arrays.asList(1,2,3,4);
		List<Integer> l2 = Arrays.asList(11,12,13,14);
		List<Integer> l3 = Arrays.asList(10,20,30,40);
		
		List<List<Integer>> listOfAllIntegers = Arrays.asList(l1,l2,l3);
		
		List<Integer> listOfList = listOfAllIntegers.stream().flatMap(x -> x.stream()).collect(Collectors.toList());
			 
		 System.out.println("List of all Integers"+listOfList);

		 String[] a = new String[] {"a","b","c"};
		 String[] b = new String[] {"aa","bb","cc"};
		 String[] c = new String[] {"a2","b2","c2"};
		 
		 List<String> listOfAllChars = Arrays.asList(a,b,c).stream().flatMap(x -> Arrays.stream(x))
				                         .collect(Collectors.toList());
		 
		 
		 System.out.println(listOfAllChars);
		 
		 
		 
		 
		 
		 
	}

}
