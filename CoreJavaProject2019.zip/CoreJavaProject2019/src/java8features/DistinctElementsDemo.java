package java8features;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class DistinctElementsDemo {

	public static void main(String[] args) {
		List<Integer> intlist = Arrays.asList(1, 2, 3, 1, 2, 3, 3, 4, 4, 5, 5);

		List<Integer> distint = intlist.stream().distinct().collect(Collectors.toList());

		List<String> stlist = Arrays.asList("aaryanna".split(""));
		List<String> distst = stlist.stream().distinct().collect(Collectors.toList());

//		System.out.println(distint);
		System.out.println(distst);

		/*int[] ar = new int[] { 10, 20, 30, 40 };

		List<Integer> list = Arrays.asList(10,20,30,40);
		
			
*/			

	}

}
