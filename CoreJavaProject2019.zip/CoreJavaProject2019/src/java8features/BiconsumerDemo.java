package java8features;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

public class BiconsumerDemo {

	static void showDetails(Map<Integer, String> map, String name) {

		System.out.println("---" + name + " -- records--\t");

		map.forEach((k, v) -> System.out.println("key\t" + k + " and value\t" + v));
	}

	public static void main(String[] args) {

		Map<Integer, String> map = new HashMap<Integer, String>();
		map.put(1, "Ranga");
		map.put(2, "Venu");
		map.put(3, "Raja");
		map.put(4, "Raghu");

		/*
		 * BiConsumer<Map<Integer, String>, String> bicon = BiconsumerDemo::showDetails;
		 * bicon.accept(map, "Students");
		 */

		// using lamda Exp
		System.out.println("----Using LambdaExp----");
		BiConsumer<Map<Integer, String>, String> bicon1 = (lmap, name) -> {
			System.out.println("---" + name + "---");
			map.forEach((k, v) -> System.out.println("key\t" + k + "Value\t" + v));
		};
		bicon1.accept(map, "Employees");

	}

}
