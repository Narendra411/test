package apr15assessment;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

class CharactersCount {
    private final String name;
    private final Integer distinctCharacterCount;
    
    public CharactersCount(String name, Integer distinctCharacterCount) {
        this.name = name;
        this.distinctCharacterCount = distinctCharacterCount;
    }
    
    @Override
    public String toString() {
        return "\"" + this.name + "\" has " + this.distinctCharacterCount + " distinct characters.";
    }
}

class Filter{

    public static String nameStartingWithPrefix(String name){
    	List<String> stlist = Arrays.asList(name.split(""));
		List<String> distst = stlist.stream().distinct().collect(Collectors.toList());
    	
        return
    }
}

class Mapper{

    public static CharactersCount getDistinctCharactersCount(){

        return null;
    }
}

public class DistinctCharacter {
    private static final Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {
        List<String> names = Arrays.asList(
                "aaryanna",
                "aayanna",
                "airianna",
                "alassandra",
                "allanna",
                "allannah",
                "allessandra",
                "allianna",
                "allyanna",
                "anastaisa",
                "anastashia",
                "anastasia",
                "annabella",
                "annabelle",
                "annebelle"
        );
        
        names.stream()
                .filter(Filter.nameStartingWithPrefix(scanner.nextLine()))
               // .map(Mapper.getDistinctCharactersCount())
                .forEachOrdered(System.out::println);
    }
}