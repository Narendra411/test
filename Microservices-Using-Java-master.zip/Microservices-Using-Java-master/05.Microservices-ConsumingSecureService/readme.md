* Create a copy of 03.Microservices-ConfigConsumer project

* add following entries in bootstrap.properties
	
		spring.cloud.config.username=khulja
		spring.cloud.config.password=simsim

* Access the **/rate** end point 
	
