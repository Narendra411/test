* Create a project with following dependencies   

	Task 
	Mysql connector 
	Springboot-jdbc-starter 
	
* Update the connection details in application.properties
* Add command line arguments