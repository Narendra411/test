package org.cap.demo;

public class DeadLockDemo {

	public static void main(String[] args) {
		
		final String firstName="tom";
		final String lastName="Jerry";
		
		
		Thread t1=new Thread() {
			
			@Override
			public void run() {
				synchronized (firstName) {
					System.out.println("Firstname locked by thread..........");
				
				
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					try {
						firstName.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					synchronized (lastName) {
						System.out.println("lastname locked by thread..........");
					}
				}
			}
		};
		
		
		Thread t2=new Thread() {
			
			@Override
			public void run() {
				synchronized (lastName) {
					System.out.println("lastname locked by thread..........");
				
				
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					synchronized (firstName) {
						System.out.println("Firstname locked by thread..........");
					}
				}
			}
		};
		
		
		t1.start();
		t2.start();
		
	}

}
