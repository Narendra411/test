package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		
		MyClass t=new MyClass(12,"T1");
		t.start();
		
		try {
			t.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		MyClass t1=new MyClass(15,"T2");
		t1.start();
		
/*		
		MyClass t2=new MyClass(17,"T3");
		t2.start();
*/	}

}
