package org.cap.demo;

public class Account {
	
	private double balance;
	
	public Account(double balance) {
		this.balance=balance;
	}
	
	
	public synchronized void deposit(double amount) {
		System.out.println("Deposit started.............."+Thread.currentThread().getName());
		this.balance+=amount;
		System.out.println("**********Balance:"+this.balance+"**************");
		
		System.out.println("Withdraw started.............."+Thread.currentThread().getName());
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//System.out.println("Withdraw started..............");
		this.notify();
	}
	
	public synchronized void withdraw(double amount) {
		System.out.println("Withdraw started.............."+Thread.currentThread().getName());
		if(this.balance<amount) {
			try {
				System.out.println("Waiting for Deposit............."+Thread.currentThread().getName());
				this.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			this.balance-=amount;
			System.out.println("**********Balance:"+this.balance+"**************"+Thread.currentThread().getName());
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		System.out.println("Withdraw Completed.............."+Thread.currentThread().getName());
	}


}
