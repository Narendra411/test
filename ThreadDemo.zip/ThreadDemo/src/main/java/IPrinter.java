public interface IPrinter {
	abstract int printData() throws PrintException;
}